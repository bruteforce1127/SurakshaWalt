package com.kucp1127.SurakshaWalt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurakshaWaltApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurakshaWaltApplication.class, args);
	}

}
