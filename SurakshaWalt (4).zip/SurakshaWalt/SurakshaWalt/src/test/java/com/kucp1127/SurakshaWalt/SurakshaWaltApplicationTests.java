package com.kucp1127.SurakshaWalt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurakshaWaltApplicationTests {

	@Test
	void contextLoads() {
	}

}
